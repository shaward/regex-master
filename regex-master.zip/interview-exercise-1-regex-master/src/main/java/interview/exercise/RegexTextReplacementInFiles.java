package interview.exercise;

import org.apache.log4j.Logger;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexTextReplacementInFiles {
    protected static Logger logger = Logger.getLogger(new Object() {
    }.getClass().getEnclosingClass());

    protected static final String logHeaderString = new Object() {
    }.getClass().getEnclosingClass().getSimpleName() + "::";

    List<String> filelist = new ArrayList<String>();


    public static void process(String startingPath, String regexPattern,
           String replacement, String fileAcceptPattern) {
        String DirName = startingPath;

        if (fileAcceptPattern != null) {
            fileAcceptPattern = fileAcceptPattern.replace("*", ".*?");
        }
        Map<String, List<String>> fileMap = new HashMap<String, List<String>>();
        if (fileMap == null) {
            logger.error("Could not create a fileMap for: " + DirName);
            return;
        }
        File dirname = new File(DirName);

        List<String> fileList = new ArrayList<String>();
        if (fileList == null) {
            logger.error("Could not create a fileList.");
            return;
        }

        List<String> folderList = new ArrayList<String>();
        if (dirname.isDirectory()) {
            // get list of folders
           folderList = FileUtil.listFolders(DirName);
        }
        else if (dirname.getAbsoluteFile().isFile()){
            if (fileAcceptPattern != null) {
                Pattern uName = Pattern.compile(fileAcceptPattern);
                Matcher mUname = uName.matcher(DirName);

                if (mUname.matches())
                    fileList.add(dirname.getAbsolutePath());
            }
            else{
                fileList.add(dirname.getAbsolutePath());
            }
            fileMap.put(DirName, fileList);
        }
        else{
            System.out.println("Dirname is not directory or file.");
            System.exit(1);
        }



        if (folderList != null) {
            for (String filedir : folderList) {
                // get files in DirName and store in the hashmap with key dirname
                FileUtil.listFilesAndFilesSubDirectories(filedir, fileList,fileAcceptPattern);
                fileMap.put(filedir, fileList);

            }
        }

        // loop thru the map and process each entry
        for (Map.Entry<String, List<String>> entry : fileMap.entrySet()) {
            String key = entry.getKey();
            logger.info("processing " + key);

            List<String> fileNameList = (List) entry.getValue();
            if (fileNameList != null) {
                System.out.println(key + " : processed " +  fileNameList.size() + " files");
                for (String fileName : fileNameList) {
                    File infile = new File(fileName);
                    if (!infile.exists() || !infile.canRead()) {
                        logger.error(logHeaderString + "Could not read file " + fileName);
                    } else {
                        logger.info("processing " + fileName);
                        processFile(fileName, regexPattern,replacement );
                    }
                }
            }

        } //for
    }

    public static void processFile(String fileName, String regexPattern,String replacement ){
        try {
            Map<String,Integer>wordmap = new HashMap<String,Integer>();
            String content = readFile(fileName, StandardCharsets.UTF_8);
            Pattern p = Pattern.compile(regexPattern);
            //  get a matcher object
            Matcher m = p.matcher(content);
            StringBuffer sb = new StringBuffer(content.length());
            int count = 0;
            String tmp = replacement.replace("$1", "").replace("$3","");
            System.out.println(fileName + " :");
            System.out.println("Replaced to '" + tmp + "':");
            while(m.find()) {
                String group = m.group(1);
                String word = m.group();
                count++;
                //System.out.println("Match number " + count);
                //System.out.println("goup1: "  + m.group(1));
                //System.out.println("group: "  + m.group());
                int wordCount = 0;
                if (wordmap.containsKey(word)) {
                    wordCount = wordmap.get(word);
                    wordCount++;
                    wordmap.put(word, wordCount);
                }
                else{ // first time
                    wordmap.put(word, 1);
                }
                m.appendReplacement(sb,replacement);

            }
            m.appendTail(sb);
            //System.out.println(sb.toString());
            String newfile = fileName + ".processed";
            try {
                PrintWriter out = new PrintWriter(newfile);
                out.println(sb.toString());
                out.close();
            }
            catch (Exception e){
                e.printStackTrace();
            }

            // print results
            for (Map.Entry<String, Integer> entry : wordmap.entrySet()) {
                System.out.println("* " + entry.getKey() + " :" + entry.getValue() + " occurence");
            }
            System.out.println();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }



    public static String readFile(String path, Charset encoding)
            throws IOException
    {
        byte[] encoded = Files.readAllBytes(Paths.get(path));
        return new String(encoded, encoding);
    }


    public static void main(String[] args) {
        String startingDir = null, regexPattern = null, replacement = null, fileAcceptPattern = null;
        if (args.length >= 3) {
            startingDir = args[0];

            regexPattern = args[1];
            if (regexPattern != null) {
                regexPattern = regexPattern.replace("\'", "");
            }

            replacement = args[2];
            if(replacement != null) {
                replacement = replacement.replace("\'", "");
            }

        }
        if (args.length >= 4) {
            fileAcceptPattern = args[3];
        }
        if (startingDir != null) {
            process(startingDir, regexPattern, replacement, fileAcceptPattern);
        } else {
            System.out.println("Expected at least 3 parameters but got " + args.length);
        }
    }



}
