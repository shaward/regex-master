package interview.exercise;

import org.apache.log4j.Logger;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class FileUtil {
    protected static Logger logger = Logger.getLogger(new Object() {
    }.getClass().getEnclosingClass());




    /**
     * List all the folder under a directory
     * @param directoryName to be listed
     */

    public static List<String> listFolders(String directoryName){

        List<String>folderList = new ArrayList<String>();
        if (folderList == null){
            logger.error("Could not create a folderList");
            return null;
        }
        File directory = new File(directoryName);

        //get all the files from a directory

        File[] fList = directory.listFiles();
        if (fList == null){
            logger.error(directoryName + " is empty");
            return null;
        }

        for (File file : fList){

            if (file.isDirectory()){

                //System.out.println(file.getName());
                folderList.add(file.getAbsolutePath());
            }

        }
        return folderList;

    }

    /**
     * List all files from a directory and its subdirectories
     * @param directoryName to be listed
     */

    public static void  listFilesAndFilesSubDirectories(String directoryName, List<String> fileList, String regex){

        File directory = new File(directoryName);

//get all the files from a directory

        File[] fList = directory.listFiles();
        if (fList == null){
            logger.error(directoryName + " is empty");
            return;
        }

        for (File file : fList){

            if (file.isFile()){
                if (regex != null) {
                    Pattern uName = Pattern.compile(regex);
                    Matcher mUname = uName.matcher(file.getName());

                    if (mUname.matches())
                        fileList.add(file.getAbsolutePath());
                }
                else{
                    fileList.add(file.getAbsolutePath());
                }

            } else if (file.isDirectory()){

                listFilesAndFilesSubDirectories(file.getAbsolutePath(),fileList,regex);

            }

        }
    }
}
