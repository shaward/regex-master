package interview.exercise;

import org.junit.Test;

public class RegexTextReplacementInFilesTest {

    @Test
    public void testSanity() {
        System.out.println("JUnit test works");
    }
}
